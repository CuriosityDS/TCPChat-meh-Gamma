﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SuperSimpleTcp;
namespace TCPClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SimpleTcpClient client;
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (client.IsConnected)
                {
                    client.Send(textBox3.Text);
                    textBox2.Text += $"Me:{textBox3.Text}{Environment.NewLine}";
                    textBox3.Text = string.Empty;
                }
            } catch { textBox2.Text += $"Sending error...{Environment.NewLine}"; }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            client = new SimpleTcpClient(textBox1.Text);
            client.Events.Connected += Events_Connected;
            client.Events.DataReceived += Events_DataReceived;
            client.Events.Disconnected += Events_Disconnected;
            button2.Enabled = false;
        }

        private void Events_Disconnected(object sender, ConnectionEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                textBox2.Text += $"Disconnected{Environment.NewLine}";
            });
        }

        private void Events_DataReceived(object sender, DataReceivedEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                textBox2.Text += $"{Encoding.UTF8.GetString(e.Data.Array, 0, e.Data.Count)}{Environment.NewLine}";
            });
        }

        private void Events_Connected(object sender, ConnectionEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                textBox2.Text += $"Connected{Environment.NewLine}";
            });
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                client.Connect();
                button2.Enabled = true;
                button3.Enabled = false;
            }
            catch { textBox2.Text += $"Error Connected{Environment.NewLine}"; }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

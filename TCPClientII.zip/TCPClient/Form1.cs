﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SuperSimpleTcp;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TCPClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SimpleTcpClient client;
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (client.IsConnected)
                {
                    string Nickname = textBox1.Text;
                    client.SendAsync(textBox1.Text +"/" + textBox3.Text);
                    textBox2.Text += $"{Nickname}:{textBox3.Text}{Environment.NewLine}";
                    textBox3.Text = string.Empty;
                }
            } catch { textBox2.Text += $"Sending error...{Environment.NewLine}"; }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            client = new SimpleTcpClient("127.0.0.1:8888");
            client.Events.Connected += Events_Connected;
            client.Events.DataReceived += Events_DataReceived;
            client.Events.Disconnected += Events_Disconnected;
            button2.Enabled = false;
        }

        private void Events_Disconnected(object sender, ConnectionEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                textBox2.Text += $"Disconnected{Environment.NewLine}";
            });
        }

        private void Events_DataReceived(object sender, DataReceivedEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                textBox2.Text += $"{Encoding.UTF8.GetString(e.Data.Array, 0, e.Data.Count)}{Environment.NewLine}";
            });
        }

        private void Events_Connected(object sender, ConnectionEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                textBox2.Text += $"Connected{Environment.NewLine}";
            });
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Connect();
        }
        async Task Connect()
        {
            await Task.Run(() =>
        {
            try
            {
                client.Connect();
                button2.Enabled = true;
                button3.Enabled = false;
                textBox3.ReadOnly = false;
                textBox1.ReadOnly = true;
                button1.Enabled = true;
                client.SendAsync(textBox1.Text + "/");
            }
            catch { textBox2.Text += $"Error Connected{Environment.NewLine}"; }
        });

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Disconnect();
        }
        async Task Disconnect()
        {
            await Task.Run(() =>
            {
                try
                {
                    client.Disconnect();
                    button2.Enabled = false;
                    button3.Enabled = true;
                    textBox3.ReadOnly = true;
                    textBox1.ReadOnly = false;
                    button1.Enabled = false;
                }
                catch { Application.Exit(); }
            });

        }
    }
}

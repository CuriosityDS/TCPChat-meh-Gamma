﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SuperSimpleTcp;
using static System.Net.Mime.MediaTypeNames;

namespace TCPServer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string[] clients = new string[0];
        string[] Nick_clients = new string[0];
        SimpleTcpServer server;
        private void Form1_Load(object sender, EventArgs e)
        {
            button2.Enabled = false;
            button1.Enabled = false;
            server = new SimpleTcpServer("127.0.0.1:8888");
            server.Events.ClientConnected += Events_ClientConnected;
            server.Events.ClientDisconnected += Events_ClientDisconnected;
            server.Events.DataReceived += Events_DataReceived;

        }

        private void Events_DataReceived(object sender, DataReceivedEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                string Decoderdata = Encoding.UTF8.GetString(e.Data.Array, 0, e.Data.Count);
                string DnPush = e.IpPort;
                if (Decoderdata.EndsWith("/"))
                {
                    string NickNameArc = Decoderdata.Substring(0, Decoderdata.IndexOf('/'));
                }
                else
                {
                    string NickName = Decoderdata.Substring(0, Decoderdata.IndexOf('/'));
                    textBox2.Text += $"{NickName}:{Decoderdata.Substring(Decoderdata.IndexOf('/') + 1)}{Environment.NewLine}";
                    for (int i = 0; i < clients.Length; i++)
                    {
                        if (DnPush != clients[i])
                            server.Send($"{clients[i]}", NickName + ":" + Decoderdata.Substring(Decoderdata.IndexOf('/') + 1));
                    }
                }
            });
        }

        private void Events_ClientDisconnected(object sender, ConnectionEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                textBox2.Text += $"{e.IpPort} DISCONNECTED. {Environment.NewLine}";
                clients = clients.Where(val => val != Convert.ToString(e.IpPort)).ToArray();
                IPClient.Items.Remove(e.IpPort);
            });
        }

        private void Events_ClientConnected(object sender, ConnectionEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
                {
                    textBox2.Text += $"{e.IpPort} CONNECTED. {Environment.NewLine}";
                    clients = clients.Append(Convert.ToString(e.IpPort)).ToArray();
                    IPClient.Items.Add(e.IpPort);
                });
        }

        private void button3_Click(object sender, EventArgs e)
        {
            server.Start();
            textBox2.Text += $"Starting server...{Environment.NewLine}";
            button3.Enabled = false;
            button2.Enabled = true;
            button1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                var strWithoutSpaces = textBox3.Text.Replace(" ", "");
                if (strWithoutSpaces != "")
                {
                    for (int i = 0; i < clients.Length; i++)
                    {
                        server.Send($"{clients[i]}", "Server:" + textBox3.Text);
                    }
                    textBox2.Text += $"Server:{textBox3.Text}{Environment.NewLine}";
                }
                textBox3.Text = string.Empty;
            }
            catch { textBox2.Text += $"Sending error...{Environment.NewLine}"; }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void IPClient_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                textBox2.Text += $"Подключенные клиенты:{clients.Length}{Environment.NewLine}";
                for (int i = 0; i < clients.Length; i++)
                {
                    textBox2.Text += $"{clients[i]}{Environment.NewLine}";
                }
            }
            catch { textBox2.Text += $"error...{Environment.NewLine}"; }
        }
    }
}
